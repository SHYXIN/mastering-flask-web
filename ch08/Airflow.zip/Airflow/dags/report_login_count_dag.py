from airflow import DAG
from airflow.operators.python import PythonOperator
from airflow.providers.http.operators.http import SimpleHttpOperator
from datetime import datetime
import json

def handle_response(response, **context):
    if response.status_code == 201:
        print("executed API successfully...")
        return True
    else:
        print("executed with errors...")
        return False

def count_login(ti, **context):
    data = ti.xcom_pull(task_ids=['list_all_login'])
    if not len(data):
        raise ValueError('Data is empty')
    records_dict = json.loads(data[0])
    count = len(records_dict["records"])
    ti.xcom_push(key="records", value=count)
    return count

def return_report(ti, **context):
    data = ti.xcom_pull(task_ids=['report_count'])
    if not len(data):
        raise ValueError('Data is empty')
    message = json.loads(data[0])
    report_msg = message["message"]
    ti.xcom_push(key="report_msg", value=report_msg)
    return report_msg
   
with DAG(dag_id="report_login_count",
    description="Report the number of login accounts",
    start_date=datetime(2023, 12, 27),
    schedule_interval="0 12 * * *",
    ) as dag:
    
    task1 = SimpleHttpOperator(
        task_id="list_all_login",
        method="GET",
        http_conn_id="packt_dag",
        endpoint="/ch08/login/list/all",
        headers={"Content-Type": "application/json"},
        response_check=lambda response: handle_response(response),
        dag=dag
    )
    task2 = PythonOperator(
        task_id='count_login',
        python_callable=count_login,
        provide_context=True,
        do_xcom_push=True,
        dag=dag
    )
    task3 = SimpleHttpOperator(
        task_id='report_count',
        method="GET",
        http_conn_id="packt_dag",
        endpoint="/ch08/login/report/count",
        data={"login_count": "{{ task_instance.xcom_pull(task_ids=['list_all_login','count_login'], key='records')[0] }}"},
        headers={"Content-Type": "application/json"},
        dag=dag
    )
    
    task4 = PythonOperator(
        task_id='return_report',
        python_callable=return_report,
        provide_context=True,
        do_xcom_push=True,
        dag=dag
    )
    
task1 >> task2 >> task3 >> task4